using EduHub.Ch01.Domain;

Console.WriteLine("===== STEP 1: CREATE CLUB =====");

var club = Club.Create(
    "Tech Club",
    "Technology and Programming Club");

Console.WriteLine($"Club Name: {club.Name}");

Console.WriteLine();
Console.WriteLine("===== STEP 2: ADD MEMBERS =====");

var member1 = Member.Create(
    "Nguyen Hong Sa",
    "nguyenhongsa@gmail.com",
    "11112006");

var member2 = Member.Create(
    "Lac Thien Hy",
    "lacthienhy@gmail.com",
    "23072006");

var member3 = Member.Create(
    "Orion",
    "orion@gmail.com",
    "15092022");

club.AddMember(member1);
club.AddMember(member2);
club.AddMember(member3);

Console.WriteLine($"Total Members: {club.MemberCount()}");

Console.WriteLine();
Console.WriteLine("===== STEP 3: CREATE EVENT =====");

var workshop = Event.Create(
    club.Id,
    "AI Workshop",
    DateTime.Now.AddDays(7),
    50,
    false);

Console.WriteLine($"Event: {workshop.Title}");

Console.WriteLine();
Console.WriteLine("===== STEP 4: REGISTRATION =====");

var registration1 = Registration.Create(
    member1.Id,
    workshop.Id);

var registration2 = Registration.Create(
    member2.Id,
    workshop.Id);

registration1.Confirm();
registration2.Confirm();

Console.WriteLine("Registration 1 Confirmed");
Console.WriteLine("Registration 2 Confirmed");

Console.WriteLine();
Console.WriteLine("===== STEP 5: CHECK-IN =====");

var checkIn = CheckIn.Create(
    registration1.Id,
    CheckInMethod.QRCode);

Console.WriteLine(checkIn.Summary());

Console.WriteLine();
Console.WriteLine("===== STEP 6: REPORT =====");

Console.WriteLine($"Club: {club.Name}");
Console.WriteLine($"Members: {club.MemberCount()}");
Console.WriteLine($"Event: {workshop.Title}");
Console.WriteLine("Registrations: 2");
Console.WriteLine("Check-ins: 1");

Console.WriteLine();
Console.WriteLine("Participants:");

Console.WriteLine(member1.Name);
Console.WriteLine(member2.Name);

Console.WriteLine();
Console.WriteLine("===== STEP 7: BUSINESS RULE TEST =====");

try
{
    registration2.Cancel();
    registration2.Confirm();
}
catch (InvalidOperationException ex)
{
    Console.WriteLine(ex.Message);
}