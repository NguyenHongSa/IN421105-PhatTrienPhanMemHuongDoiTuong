## 1. Mô tả thiết kế Domain (Domain Design)

Hệ thống **EduHub** (Quản lý Câu lạc bộ & Sự kiện sinh viên) được thiết kế theo hướng đối tượng (OOP) bao gồm 5 thực thể chính sau:

1. **Member (Thành viên):** 
   - Đại diện cho sinh viên tham gia hệ thống.
   - Quản lý thông tin cá nhân (`Id`, `Name`, `Email`, `StudentCode`, `JoinedAt`)[cite: 2, 3] và cung cấp phương thức kiểm tra trạng thái `IsActive()`[cite: 3].
2. **Club (Câu lạc bộ):** 
   - Đơn vị quản lý các hoạt động phong trào và sinh viên.
   - Chứa danh sách thành viên (`Members`)[cite: 3], hỗ trợ thêm thành viên qua `AddMember()` và đếm số lượng qua `MemberCount()`[cite: 3].
3. **Event (Sự kiện):** 
   - Đại diện cho các chương trình/workshop do một `Club` cụ thể tổ chức thông qua khóa ngoại `ClubId`[cite: 3].
   - Quản lý giới hạn chỗ ngồi (`Capacity`) và kiểm tra sức chứa thông qua phương thức `HasCapacity()`[cite: 3].
4. **Registration (Phiếu đăng ký):** 
   - Bảng trung gian thể hiện mối quan hệ nhiều-nhiều giữa `Member` và `Event`[cite: 2].
   - Quản lý trạng thái đăng ký (`Status`) với các hành vi nghiệp vụ cốt lõi như `Confirm()` và `Cancel()`[cite: 3].
5. **CheckIn (Điểm danh):** 
   - Ghi nhận việc tham gia thực tế của thành viên tại sự kiện, liên kết quan hệ 1-1 (`0..1`) với một phiếu đăng ký hợp lệ (`RegistrationId`)[cite: 2, 3].
   - Cung cấp phương thức `Summary()` để xuất chuỗi thông tin tóm tắt điểm danh[cite: 3, 4].

### Mối quan hệ giữa các lớp:
- `Club` (1) gắn kết với `Member` (*)[cite: 2].
- `Club` (1) tổ chức `Event` (*)[cite: 2].
- `Member` (1) tạo các phiếu `Registration` (*)[cite: 2].
- `Event` (1) tiếp nhận các phiếu `Registration` (*)[cite: 2].
- `Registration` (1) liên kết với một bản ghi `CheckIn` (0..1)[cite: 2].

## 2. Cách chạy ứng dụng

1. Đảm bảo máy tính của bạn đã được cài đặt **.NET 10 SDK**[cite: 4].
2. Mở Terminal (Command Prompt / PowerShell / VS Code Terminal) tại thư mục chứa file `EduHub.Ch01.csproj`.
3. Chạy lệnh sau để khởi chạy ứng dụng console:
   ```