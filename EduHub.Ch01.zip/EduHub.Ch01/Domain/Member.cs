namespace EduHub.Ch01.Domain;

/// <summary>
/// Represents a club member.
/// </summary>
public class Member
{
    public Guid Id { get; private set; }
    public string Name { get; private set; }
    public string Email { get; private set; }
    public string StudentCode { get; private set; }
    public DateTime JoinedAt { get; private set; }

    private Member(
        Guid id,
        string name,
        string email,
        string studentCode,
        DateTime joinedAt)
    {
        Id = id;
        Name = name;
        Email = email;
        StudentCode = studentCode;
        JoinedAt = joinedAt;
    }

    public static Member Create(
        string name,
        string email,
        string studentCode)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Name is required.");

        if (!email.Contains("@"))
            throw new ArgumentException("Invalid email.");

        return new Member(
            Guid.NewGuid(),
            name,
            email,
            studentCode,
            DateTime.Now);
    }

    public bool IsActive()
    {
        return true;
    }
}