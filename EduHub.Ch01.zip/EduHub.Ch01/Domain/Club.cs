namespace EduHub.Ch01.Domain;

/// <summary>
/// Represents a student club.
/// </summary>
public class Club
{
    public Guid Id { get; private set; }
    public string Name { get; private set; }
    public string Description { get; private set; }
    public DateTime CreatedAt { get; private set; }

    public List<Member> Members { get; private set; }

    private Club(
        Guid id,
        string name,
        string description)
    {
        Id = id;
        Name = name;
        Description = description;
        CreatedAt = DateTime.Now;
        Members = new List<Member>();
    }

    public static Club Create(
        string name,
        string description)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Name is required.");

        return new Club(
            Guid.NewGuid(),
            name,
            description);
    }

    public void AddMember(Member member)
    {
        Members.Add(member);
    }

    public int MemberCount()
    {
        return Members.Count;
    }
}