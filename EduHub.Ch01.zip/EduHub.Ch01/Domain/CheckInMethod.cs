namespace EduHub.Ch01.Domain;

public enum CheckInMethod
{
    QRCode,
    Manual
}