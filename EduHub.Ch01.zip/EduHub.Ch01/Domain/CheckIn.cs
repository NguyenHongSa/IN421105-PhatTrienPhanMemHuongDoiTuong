namespace EduHub.Ch01.Domain;

public class CheckIn
{
    public Guid Id { get; private set; }
    public Guid RegistrationId { get; private set; }
    public DateTime CheckedInAt { get; private set; }
    public CheckInMethod Method { get; private set; }

    private CheckIn(
        Guid registrationId,
        CheckInMethod method)
    {
        Id = Guid.NewGuid();
        RegistrationId = registrationId;
        Method = method;
        CheckedInAt = DateTime.Now;
    }

    public static CheckIn Create(
        Guid registrationId,
        CheckInMethod method)
    {
        return new CheckIn(
            registrationId,
            method);
    }

    public string Summary()
    {
        return $"Checked in by {Method} at {CheckedInAt}";
    }
}