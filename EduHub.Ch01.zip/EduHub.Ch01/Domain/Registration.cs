namespace EduHub.Ch01.Domain;

/// <summary>
/// Represents an event registration.
/// </summary>
public class Registration
{
    public Guid Id { get; private set; }
    public Guid MemberId { get; private set; }
    public Guid EventId { get; private set; }
    public DateTime RegisteredAt { get; private set; }
    public RegistrationStatus Status { get; private set; }

    private Registration(
        Guid memberId,
        Guid eventId)
    {
        Id = Guid.NewGuid();
        MemberId = memberId;
        EventId = eventId;
        RegisteredAt = DateTime.Now;
        Status = RegistrationStatus.Pending;
    }

    public static Registration Create(
        Guid memberId,
        Guid eventId)
    {
        return new Registration(
            memberId,
            eventId);
    }

    public void Confirm()
    {
        if (Status == RegistrationStatus.Cancelled)
            throw new InvalidOperationException(
                "Cancelled registration cannot be confirmed.");

        Status = RegistrationStatus.Confirmed;
    }

    public void Cancel()
    {
        Status = RegistrationStatus.Cancelled;
    }
}