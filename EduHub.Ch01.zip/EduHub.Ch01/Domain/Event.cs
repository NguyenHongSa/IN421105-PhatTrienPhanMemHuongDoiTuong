namespace EduHub.Ch01.Domain;

/// <summary>
/// Represents a club event.
/// </summary>
public class Event
{
	public Guid Id { get; private set; }
	public Guid ClubId { get; private set; }
	public string Title { get; private set; }
	public DateTime Date { get; private set; }
	public int Capacity { get; private set; }
	public bool IsOnline { get; private set; }

	private Event(
		Guid clubId,
		string title,
		DateTime date,
		int capacity,
		bool isOnline)
	{
		Id = Guid.NewGuid();
		ClubId = clubId;
		Title = title;
		Date = date;
		Capacity = capacity;
		IsOnline = isOnline;
	}

	public static Event Create(
		Guid clubId,
		string title,
		DateTime date,
		int capacity,
		bool isOnline)
	{
		if (capacity <= 0)
			throw new ArgumentException("Capacity must be greater than 0.");

		return new Event(
			clubId,
			title,
			date,
			capacity,
			isOnline);
	}

	public bool HasCapacity(int registeredCount)
	{
		return registeredCount < Capacity;
	}
}