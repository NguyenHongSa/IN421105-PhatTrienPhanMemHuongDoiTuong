using EduHub.Ch02.Domain;
using EduHub.Ch02.Interfaces;

namespace EduHub.Ch02.Services;

public class LogNotifier : IEventObserver
{
    private readonly IAppLogger _logger;
    public LogNotifier(IAppLogger logger) => _logger = logger;

    public void OnEventCreated(Event ev, Club club)
    {
        _logger.Info($"[LOG] Event created: '{ev.Title}' ({club.Name})");
    }
}

public class EmailNotifier : IEventObserver
{
    private readonly INotificationService _notifier;
    public EmailNotifier(INotificationService notifier) => _notifier = notifier;

    public void OnEventCreated(Event ev, Club club)
    {
        _notifier.Send("a@student.dthu.edu.vn", $"New event '{ev.Title}' in club {club.Name}");
    }
}