using EduHub.Ch02.Interfaces;

namespace EduHub.Ch02.Services;

public record ClubStat(string ClubName, int Members);

public class CsvReportStrategy : IReportStrategy
{
    public string Name => "CSV";

    public string Render(IReadOnlyList<ClubStat> stats)
    {
        return "Club,Members\n" + string.Join("\n", stats.Select(s => $"{s.ClubName},{s.Members}"));
    }
}