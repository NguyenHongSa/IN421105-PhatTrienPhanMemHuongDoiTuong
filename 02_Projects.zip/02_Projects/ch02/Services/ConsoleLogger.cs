using EduHub.Ch02.Interfaces;

namespace EduHub.Ch02.Services;

public class ConsoleLogger : IAppLogger
{
    public void Info(string message) => Console.WriteLine($"[LOG] {message}");
    public void Warning(string message) => Console.WriteLine($"[WARN] {message}");
    public void Error(string message) => Console.WriteLine($"[ERROR] {message}");
}