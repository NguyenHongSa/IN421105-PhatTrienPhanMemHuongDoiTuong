using EduHub.Ch02.Interfaces;

namespace EduHub.Ch02.Services;

public class EmailNotificationService : INotificationService
{
    public void Send(string to, string message)
    {
        Console.WriteLine($"[EMAIL] to {to}: {message}");
    }
}