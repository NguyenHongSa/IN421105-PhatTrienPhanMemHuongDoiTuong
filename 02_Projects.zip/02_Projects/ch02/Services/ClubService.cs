using EduHub.Ch02.Domain;
using EduHub.Ch02.Interfaces;

namespace EduHub.Ch02.Services;

public class ClubService
{
    private readonly IClubRepository _clubRepo;
    private readonly IAppLogger _logger;
    private readonly INotificationService _notifier;

    public ClubService(IClubRepository clubRepo, IAppLogger logger, INotificationService notifier)
    {
        _clubRepo = clubRepo;
        _logger = logger;
        _notifier = notifier;
    }

    public void CreateClub(string name, string description, string presidentEmail)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Tên CLB không được để trống.");

        var club = Club.Create(name, description);
        _clubRepo.Add(club);

        _logger.Info($"Club created: {name}");
        _notifier.Send(presidentEmail, $"Chúc mừng! CLB '{name}' đã được tạo thành công.");
    }
}