using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using EduHub.Ch02.Domain;
using EduHub.Ch02.Interfaces;
using EduHub.Ch02.Repositories;
using EduHub.Ch02.Services;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.WriteLine("==================================================");
Console.WriteLine("    EDUHUB - TỔNG HỢP 5 CÂU BÀI TẬP CHƯƠNG 2");
Console.WriteLine("==================================================\n");

#region CÂU 1: PHÂN TÍCH VÀ ĐỌC FILE BÁO CÁO VI PHẠM SOLID
Console.WriteLine("--- CÂU 1: PHÂN TÍCH NGUYÊN LÝ SOLID ---");
Console.WriteLine("-> Báo cáo phân tích vi phạm SOLID của ClubManager đã có trong README.md\n");
#endregion

#region CÂU 2: REFACTORING & CONSTRUCTOR INJECTION (THỦ CÔNG)
// Ở câu 2, ta hiểu bản chất cách tiêm phụ thuộc (DI) bằng cách khởi tạo và truyền thủ công qua Constructor.
Console.WriteLine("--- CÂU 2: KHỞI TẠO VÀ TIÊM PHỤ THỤC THỦ CÔNG ---");
IAppLogger manualLogger = new ConsoleLogger();
INotificationService manualNotifier = new EmailNotificationService();
IClubRepository manualRepo = new InMemoryClubRepository();

// Tiêm trực tiếp qua Constructor của ClubService
ClubService manualClubService = new ClubService(manualRepo, manualLogger, manualNotifier);
manualClubService.CreateClub("Tech Club (Thủ công)", "Mô tả CLB", "manual@student.dthu.edu.vn");
Console.WriteLine();
#endregion

#region CÂU 5: CẤU HÌNH DEPENDENCY INJECTION (DI) CONTAINER (NÂNG CAO)
// Ở câu 5, ta sử dụng DI Container chuẩn của .NET để tự động hóa việc quản lý vòng đời và tiêm phụ thuộc.
Console.WriteLine("--- CÂU 5: CẤU HÌNH DI CONTAINER TỰ ĐỘNG (.NET HOST) ---");
var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        // Đăng ký các dịch vụ vào Container
        services.AddSingleton<IAppLogger, ConsoleLogger>();

        // CÂU 3 (DECORATOR PATTERN): Bọc Repository
        services.AddSingleton<IClubRepository>(sp =>
        {
            var logger = sp.GetRequiredService<IAppLogger>();
            return new LoggingClubRepository(new InMemoryClubRepository(), logger);
        });

        // CÂU 3 (FACTORY PATTERN)
        services.AddSingleton<INotificationServiceFactory, NotificationServiceFactory>();

        // Đăng ký Service chính
        services.AddTransient<ClubService>();
    })
    .Build();

// Lấy service tự động từ Container để chạy
var diClubService = host.Services.GetRequiredService<ClubService>();
diClubService.CreateClub("AI Club (DI Container)", "CLB Trí tuệ nhân tạo", "ai@student.dthu.edu.vn");
Console.WriteLine();
#endregion

#region CÂU 3: ÁP DỤNG CÁC DESIGN PATTERNS
Console.WriteLine("--- CÂU 3: MINH HỌA CÁC DESIGN PATTERNS ---");

var notificationFactory = host.Services.GetRequiredService<INotificationServiceFactory>();

// 1. Factory Pattern
var emailService = notificationFactory.Create(NotificationChannel.Email);
emailService.Send("student@dthu.edu.vn", "Test Factory Pattern!");

// 2. Strategy Pattern
var stats = new List<ClubStat> { new("AI Club", 50), new("Tech Club", 45) };
IReportStrategy strategy = new CsvReportStrategy();
Console.WriteLine($"[Strategy Report - {strategy.Name}]:\n{strategy.Render(stats)}");

// 3. Observer Pattern
var clubRepo = host.Services.GetRequiredService<IClubRepository>();
var sampleClub = clubRepo.GetAll().FirstOrDefault() ?? Club.Create("EduClub", "Mô tả");
var newEvent = Event.Create("Workshop .NET", DateTime.Now.AddDays(2));
var appLogger = host.Services.GetRequiredService<IAppLogger>();

new LogNotifier(appLogger).OnEventCreated(newEvent, sampleClub);
Console.WriteLine();
#endregion

#region CÂU 4: KIỂM THỬ TỰ ĐỘNG (UNIT TESTING)
Console.WriteLine("--- CÂU 4: UNIT TESTING VỚI XUNIT ---");
Console.WriteLine("-> Kịch bản kiểm thử nằm trong project 'EduHub.Ch02.Tests'. Mở Test Explorer (Ctrl + E, T) để chạy.\n");
#endregion

Console.WriteLine("==================================================");
Console.WriteLine("        HOÀN THÀNH TẤT CẢ 5 CÂU RÕ RÀNG!");
Console.WriteLine("==================================================");