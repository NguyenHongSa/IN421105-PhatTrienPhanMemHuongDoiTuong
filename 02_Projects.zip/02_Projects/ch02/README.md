## CÂU 1: Phân tích các lỗi vi phạm nguyên lý SOLID trong `ClubManager.cs`

Sau khi khảo sát và đọc mã nguồn của lớp `ClubManager.cs` trong thư mục starter, em đã tìm và phân tích được **4 vi phạm nguyên lý SOLID** cụ thể như sau:

### 1. Vi phạm nguyên lý Single Responsibility (SRP - Trách nhiệm đơn lẻ)
* **Dấu hiệu trong code:** Phương thức `CreateClub` và các hàm xử lý bên trong lớp `ClubManager` đang ôm đồm quá nhiều việc cùng lúc:
  * Kiểm tra dữ liệu hợp lệ (validation).
  * Lưu trữ dữ liệu câu lạc bộ và thành viên (`_clubs.Add`).
  * Ghi log hệ thống ra file (`File.AppendAllText`).
  * Thực hiện gửi email thông báo (`Console.WriteLine`)[cite: 1].
* **Hậu quả:** Tạo ra một "God Class" (lớp ôm mọi việc), khiến file code trở nên quá dài, phức tạp, cực kỳ khó đọc và khó bảo trì. Mọi thay đổi nhỏ (như thay đổi định dạng log hoặc cách lưu file) đều buộc phải sửa lại lớp này[cite: 1].
* **Hướng khắc phục:** Tách `ClubManager` thành các lớp nhỏ có trách nhiệm riêng biệt: `ClubService` (điều phối nghiệp vụ), `IAppLogger` (ghi log), `INotificationService` (gửi thông báo) và `ReportService` (thống kê báo cáo)[cite: 1].

### 2. Vi phạm nguyên lý Open/Closed (OCP - Đóng/Mở)
* **Dấu hiệu trong code:** Đoạn code xử lý gửi thông báo đang sử dụng chuỗi câu lệnh điều kiện `if/else` (hoặc kiểm tra định dạng email như `@gmail.com`, `@yahoo.com`) để quyết định cách thức gửi[cite: 1].
* **Hậu quả:** Khi hệ thống yêu cầu mở rộng thêm một kênh thông báo mới hoàn toàn (ví dụ như SMS hoặc Slack), bạn bắt buộc phải mở file code cũ ra và sửa lại cấu trúc điều kiện `if/else`, vi phạm nghiêm trọng nguyên tắc đóng/mở (đóng với việc sửa đổi, mở với việc mở rộng)[cite: 1].
* **Hướng khắc phục:** Áp dụng Interface chung `INotificationService`. Mỗi kênh thông báo sẽ là một class riêng biệt cài đặt từ interface này (`EmailNotificationService`, `SmsNotificationService`, `SlackNotificationService`). Khi thêm kênh mới chỉ cần viết class mới mà không cần sửa code cũ[cite: 1].

### 3. Vi phạm nguyên lý Interface Segregation & Liskov Substitution (ISP / LSP)
* **Dấu hiệu trong code:** Thiết kế kho dữ liệu (Repository) hiện tại đang sử dụng một interface chung quá lớn, ôm đồm mọi thao tác đọc/ghi. Các thành phần chỉ có nhu cầu đọc dữ liệu (ReadOnly) bị ép phải cài đặt cả các hàm ghi, dẫn đến việc phải ném ra các ngoại lệ không hợp lệ như `NotSupportedException`[cite: 1].
* **Hậu quả:** Phá vỡ lời hứa và hợp đồng của interface, làm sập chương trình bất ngờ khi các đoạn code bên ngoài gọi nhầm vào những phương thức không được đối tượng con hỗ trợ thực tế[cite: 1].
* **Hướng khắc phục:** Tách nhỏ các interface thành các phần gọn nhẹ hơn (ví dụ tách `IClubReader` chuyên đọc và `IClubRepository` kế thừa từ `IClubReader` để ghi) để mỗi class chỉ ký hợp đồng những gì mình thực sự làm được[cite: 1].

### 4. Vi phạm nguyên lý Dependency Inversion (DIP - Đảo phụ thuộc)
* **Dấu hiệu trong code:** Bên trong các phương thức nghiệp vụ, code đang gọi trực tiếp các tiện ích hạ tầng cấp thấp như `File.AppendAllText` hay `Console.WriteLine`, đồng thời sử dụng trực tiếp từ khóa `new` để khởi tạo các đối tượng cụ thể ngay trong method[cite: 1].
* **Hậu quả:** Code bị "dính chặt" (tightly coupled) vào hệ thống file và console. Việc này khiến cho việc viết **Unit Test** trở nên bất khả thi, vì mỗi lần chạy test sẽ làm thay đổi file dữ liệu thật trên máy hoặc in rác ra màn hình[cite: 1].
* **Hướng khắc phục:** Cho các lớp cấp cao phụ thuộc vào Abstraction (Interface như `IAppLogger`, `IClubRepository`) và nhận các phụ thuộc này từ bên ngoài thông qua Constructor Injection. Lớp `Program.cs` sẽ đóng vai trò composition root duy nhất chịu trách nhiệm `new` các class cụ thể[cite: 1].

### CÂU 2: Refactoring cấu trúc thư mục & Dependency Injection (DI) thủ công
* **Cấu trúc thư mục mới sau khi refactor:**
  * `Interfaces/`: Chứa các bản hợp đồng (`IClubRepository`, `INotificationService`, `IAppLogger`,...).
  * `Services/`: Chứa các lớp xử lý nghiệp vụ (`ClubService`,...).
  * `Repositories/`: Chứa các lớp thao tác dữ liệu (`InMemoryClubRepository`,...).
  * `Domain/`: Chứa các đối tượng thực thể (`Club`, `Event`, `Member`).
* **Cơ chế DI:** Áp dụng **Constructor Injection** để tiêm các Interface vào service thay vì khởi tạo thủ công bằng từ khóa `new`, giúp giảm độ phụ thuộc (Tight Coupling).

### CÂU 3: Tích hợp các Design Patterns
Trong quá trình refactor, 4 Design Patterns cốt lõi đã được áp dụng:
1. **Factory Pattern (`NotificationServiceFactory`):** Khởi tạo linh hoạt các kênh thông báo (`Email`, `SMS`) theo tham số đầu vào.
2. **Decorator Pattern (`LoggingClubRepository`):** Bọc kho dữ liệu (`InMemoryClubRepository`) để tự động ghi log mọi thao tác mà không làm thay đổi mã nguồn gốc của Repository (tuân thủ OCP).
3. **Strategy Pattern (`IReportStrategy` / `CsvReportStrategy`):** Tách thuật toán xuất báo cáo thành các chiến lược độc lập, giúp dễ dàng mở rộng định dạng báo cáo.
4. **Observer Pattern (`IEventObserver` / `LogNotifier`, `EmailNotifier`):** Tự động phát thông báo đến các hệ thống lắng nghe ngay khi một Sự kiện (`Event`) mới được khởi tạo.

### CÂU 4: Viết Unit Test tự động với xUnit
* **Project Test:** Xây dựng project kiểm thử riêng biệt **`EduHub.Ch02.Tests`**.
* **Kịch bản kiểm thử (Theo mô hình AAA):**
  * `ClubTests.cs`: Kiểm tra tính hợp lệ khi tạo CLB và ngoại lệ (`ArgumentException`) khi để trống tên.
  * `EventTests.cs`: Kiểm tra hành vi đăng ký thành viên (`Register`) vào sự kiện.
* **Kết quả:** Toàn bộ các test case đều vượt qua thành công với 

### CÂU 5: Cấu hình Dependency Injection Container nâng cao trong .NET
* **Giải pháp:** Sử dụng `Host.CreateDefaultBuilder` và `ServiceCollection` trong file `Program.cs` để tự động hóa hoàn toàn việc quản lý vòng đời đối tượng.
* **Cấu hình Service Lifetimes:**
  * **`AddSingleton`**: Dùng cho `IAppLogger`, `IClubRepository` (Decorator) để duy trì trạng thái dữ liệu xuyên suốt ứng dụng.
  * **`AddTransient`**: Dùng cho `ClubService` và các dịch vụ xử lý nghiệp vụ.
```csharp
var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        services.AddSingleton<IAppLogger, ConsoleLogger>();
        services.AddSingleton<IClubRepository>(sp => new LoggingClubRepository(new InMemoryClubRepository(), sp.GetRequiredService<IAppLogger>()));
        services.AddSingleton<INotificationServiceFactory, NotificationServiceFactory>();
        services.AddTransient<ClubService>();
    })
    .Build();