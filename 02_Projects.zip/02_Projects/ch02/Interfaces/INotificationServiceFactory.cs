namespace EduHub.Ch02.Interfaces;

public enum NotificationChannel { Email, Sms, Slack }

public interface INotificationServiceFactory
{
    INotificationService Create(NotificationChannel channel);
}