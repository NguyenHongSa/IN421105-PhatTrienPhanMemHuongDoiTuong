using EduHub.Ch02.Domain;

namespace EduHub.Ch02.Interfaces;

public interface IReportStrategy
{
    string Name { get; }
    string Render(IReadOnlyList<ClubStat> stats);
}