namespace EduHub.Ch02.Interfaces;

public interface INotificationService
{
    void Send(string to, string message);
}