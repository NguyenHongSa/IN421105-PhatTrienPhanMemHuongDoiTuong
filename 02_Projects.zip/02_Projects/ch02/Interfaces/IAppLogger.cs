namespace EduHub.Ch02.Interfaces;

public interface IAppLogger
{
    void Info(string message);
    void Warning(string message);
    void Error(string message);
}