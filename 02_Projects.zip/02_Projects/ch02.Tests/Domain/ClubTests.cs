using Xunit;
using EduHub.Ch02.Domain;

namespace EduHub.Ch02.Tests.Domain;

public class ClubTests
{
    [Fact]
    public void CreateClub_WithValidData_ShouldSucceed()
    {
        // Arrange (Chuẩn bị dữ liệu)
        string name = "Tech Club";
        string description = "Câu lạc bộ Công nghệ thông tin";

        // Act (Thực thi hành động)
        var club = Club.Create(name, description);

        // Assert (Kiểm tra kết quả mong đợi)
        Assert.NotNull(club);
        Assert.Equal(name, club.Name);
        Assert.Equal(description, club.Description);
    }

    [Fact]
    public void CreateClub_WithEmptyName_ShouldThrowArgumentException()
    {
        // Arrange
        string name = "";
        string description = "Mô tả kiểm tra lỗi";

        // Act & Assert (Kiểm tra xem hệ thống có tung ra ngoại lệ ArgumentException không)
        Assert.Throws<ArgumentException>(() => Club.Create(name, description));
    }
}