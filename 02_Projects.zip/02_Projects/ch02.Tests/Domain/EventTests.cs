using Xunit;
using EduHub.Ch02.Domain;

namespace EduHub.Ch02.Tests.Domain;

public class EventTests
{
    [Fact]
    public void RegisterMember_ToEvent_ShouldAddSuccessfully()
    {
        // Arrange
        var ev = Event.Create("Workshop Clean Architecture", DateTime.Now.AddDays(2));
        var member = new Member("SV001", "Nguyen Van A");

        // Act
        ev.Register(member);

        // Assert
        Assert.Single(ev.Attendees);
        Assert.Contains(member, ev.Attendees);
    }
}